module sdk

import temporal

// Propagator-owned headers never pass through application payload converters or codecs.
// Memo maps use encode_map/decode_map and retain the full application key space.
pub fn (converter DataConverter) encode_headers(values map[string]PayloadValue) !map[string]temporal.TemporalApiCommonV1_Payload {
    if trace_header_key in values { return error('header key _tracer-data is reserved for trace propagation') }
    return converter.encode_map(values)!
}

pub fn (converter DataConverter) decode_headers(values map[string]temporal.TemporalApiCommonV1_Payload) !map[string]PayloadValue {
    mut application:=values.clone()
    application.delete(trace_header_key)
    return converter.decode_map(application)!
}
