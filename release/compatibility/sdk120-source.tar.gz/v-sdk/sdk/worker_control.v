module sdk

import corebridge
import sync

struct WorkerControlState {
mut:
	mutex       &sync.Mutex = sync.new_mutex()
	stopping    bool
	next_id     u64
	connections map[u64]&corebridge.Connection
}

// Share a control between workers to stop them as a group without OS signals.
@[heap]
pub struct WorkerControl {
	state &WorkerControlState = &WorkerControlState{}
}

pub fn (control &WorkerControl) shutdown() {
	mut state := control.state
	state.mutex.lock()
	defer { state.mutex.unlock() }
	state.stopping = true
	for _, connection in state.connections { connection.shutdown() }
}

fn (control &WorkerControl) attach(connection &corebridge.Connection) u64 {
	mut state := control.state
	state.mutex.lock()
	defer { state.mutex.unlock() }
	if state.stopping {
		connection.shutdown()
		return 0
	}
	state.next_id++
	state.connections[state.next_id] = connection
	return state.next_id
}

fn (control &WorkerControl) detach(id u64) {
	mut state := control.state
	state.mutex.lock()
	defer { state.mutex.unlock() }
	state.connections.delete(id)
}
