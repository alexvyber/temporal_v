Module {
	name: 'temporal_v'
	description: 'Temporal V SDK backed by pinned Rust Core'
	version: '0.0.1'
	dependencies: ['protobuf']
}
