module main

import sdk
import json2
import crypto.sha256

struct RawStartWorkflow {
	named bool
mut:
	state string
}

fn raw_start_factory() sdk.Workflow { return RawStartWorkflow{} }

fn named_start_factory() sdk.Workflow { return RawStartWorkflow{ named: true } }

fn (mut workflow RawStartWorkflow) on_event(event sdk.Event, mut context sdk.WorkflowContext) ! {
	if event.kind == .started {
		mut values := []RawActivityDescriptor{}
		for value in event.typed_arguments {
			if workflow.named && value is sdk.RawValue {
				return error('named start skipped conversion')
			}
			if !workflow.named && value !is sdk.RawValue {
				return error('dynamic start was converted')
			}
		}
		for raw in event.raw_arguments {
			mut data := raw.data()
			if data.len > 0 {
				first := data[0]
				data[0] ^= u8(255)
				if raw.data()[0] != first { return error('workflow start raw bytes borrowed') }
			}
			values << RawActivityDescriptor{ encoding: raw.encoding(), message_type: raw.message_type(), length: raw.data().len, digest: sha256.hexhash(raw.data().bytestr()) }
		}
		if workflow.named && event.arguments != ['"named"'] {
			return error('named workflow arguments changed')
		}
		workflow.state = json2.encode(RawActivitySummary{
			kind:          if workflow.named {
				'named'
			} else {
				'dynamic'
			}
			activity_type: context.info().workflow_type
			values:        values
		})
	}
	if event.kind == .signal_received && event.name == 'finish' {
		context.complete(workflow.state)!
	}
	if event.kind == .cancel_requested { context.cancel()! }
}

fn (workflow RawStartWorkflow) query(name string, arguments []string) !sdk.PayloadValue {
	return sdk.PayloadValue(workflow.state)
}

fn start_raw_workflows(options sdk.WorkerOptions, converter sdk.DataConverter) ! {
	client := sdk.connect(sdk.ClientOptions{ address: options.address, data_converter: converter })!
	defer { client.close() }
	mut handles := map[string]sdk.WorkflowHandle{}
	for label in ['empty', 'mixed', 'named', 'bad'] {
		kind := match label {
			'named' { 'v.raw-workflow.named' }
			'bad' { 'v.raw-workflow.bad' }
			else { 'v.raw-workflow.' + label }
		}
		arguments := if label == 'empty' {
			sdk.Arguments([]string{})
		} else if label == 'named' {
			sdk.Arguments('"named"')
		} else {
			raw_activity_arguments()!
		}
		handles[label] = client.start(sdk.WorkflowStart{ workflow_id: options.task_queue + '-' + label, workflow_type: kind, task_queue: options.task_queue, arguments: arguments })!
	}
	println(json2.encode(handles))
}
