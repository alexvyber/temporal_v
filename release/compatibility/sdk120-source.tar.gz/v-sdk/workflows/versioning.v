module workflows

import sdk
import json2

struct VersionedWorkflow {
mut:
	counter     Counter
	information sdk.WorkflowInfo
}

fn new_versioned_workflow() sdk.Workflow { return VersionedWorkflow{} }

fn (mut workflow VersionedWorkflow) on_event(event sdk.Event, mut context sdk.WorkflowContext) ! {
	workflow.information = context.info()
	workflow.counter.on_event(event, mut context)!
}

fn (workflow &VersionedWorkflow) query(name string, arguments []string) !sdk.PayloadValue {
	if name == 'versioning' { return json2.encode(workflow.information) }
	return workflow.counter.query(name, arguments)!
}
